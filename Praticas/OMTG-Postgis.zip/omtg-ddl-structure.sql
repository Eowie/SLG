-- Create table Docente
CREATE TABLE Docente (
  NumeroFuncionario INTEGER,
  Gabinete TEXT,
  NomeDepartamento TEXT,
  Nome TEXT,
  Telefone INTEGER,
  Email TEXT,
  CONSTRAINT pk_Docente PRIMARY KEY (NumeroFuncionario)
);

-- Create table Edificio
CREATE TABLE Edificio (
  NomeEdificio TEXT,
  Descricao TEXT,
  geom ast_polygon,
  CONSTRAINT pk_Edificio PRIMARY KEY (NomeEdificio)
);

-- Create the spatial index on geom column of Edificio
CREATE INDEX SIDX_Edificio
  ON Edificio
  USING GIST (geom);

-- Create table Curso_UC
CREATE TABLE Curso_UC (
  NomeCurso TEXT,
  CodigoUC INTEGER,
  CONSTRAINT pk_Curso_UC PRIMARY KEY (NomeCurso,CodigoUC)
);

-- Create table Cruzamento
CREATE TABLE Cruzamento (
  geom ast_node
);

-- Create the spatial index on geom column of Cruzamento
CREATE INDEX SIDX_Cruzamento
  ON Cruzamento
  USING GIST (geom);

-- Create table Aluno
CREATE TABLE Aluno (
  NumeroAluno INTEGER,
  Nome TEXT,
  Telefone INTEGER,
  Email TEXT,
  Morada TEXT,
  NomeCurso TEXT,
  CONSTRAINT pk_Aluno PRIMARY KEY (NumeroAluno)
);

-- Create table SalaAula
CREATE TABLE SalaAula (
  geom ast_polygon
);

-- Create the spatial index on geom column of SalaAula
CREATE INDEX SIDX_SalaAula
  ON SalaAula
  USING GIST (geom);

-- Create table Estacionamento
CREATE TABLE Estacionamento (
  Designacao TEXT,
  Espacos INTEGER,
  geom ast_polygon
);

-- Create the spatial index on geom column of Estacionamento
CREATE INDEX SIDX_Estacionamento
  ON Estacionamento
  USING GIST (geom);

-- Create table Curso
CREATE TABLE Curso (
  NomeCurso TEXT,
  Ciclo INTEGER,
  Descricao TEXT,
  CONSTRAINT pk_Curso PRIMARY KEY (NomeCurso)
);

-- Create table UnidadeCurricular
CREATE TABLE UnidadeCurricular (
  NomeUC TEXT,
  CodigoUC TEXT,
  Ciclo INTEGER,
  Descricao TEXT,
  ECTS INTEGER,
  CONSTRAINT pk_UnidadeCurricular PRIMARY KEY (CodigoUC)
);

-- Create table CaminhoPedonal
CREATE TABLE CaminhoPedonal (
  Nome TEXT,
  geom ast_biline
);

-- Create the spatial index on geom column of CaminhoPedonal
CREATE INDEX SIDX_CaminhoPedonal
  ON CaminhoPedonal
  USING GIST (geom);

-- Create table SalaComputadores
CREATE TABLE SalaComputadores (
  NrPcs INTEGER,
  geom ast_polygon
);

-- Create the spatial index on geom column of SalaComputadores
CREATE INDEX SIDX_SalaComputadores
  ON SalaComputadores
  USING GIST (geom);

-- Create table Sala_UC
CREATE TABLE Sala_UC (
  NumeroSala TEXT,
  CodigoUC TEXT,
  CONSTRAINT pk_Sala_UC PRIMARY KEY (NumeroSala,CodigoUC)
);

-- Create table Docente_UC
CREATE TABLE Docente_UC (
  NumeroFuncionario INTEGER,
  CodigoUC INTEGER,
  CONSTRAINT pk_Docente_UC PRIMARY KEY (NumeroFuncionario,CodigoUC)
);

-- Create table Departamento
CREATE TABLE Departamento (
  NomeDepartamento TEXT,
  CONSTRAINT pk_Departamento PRIMARY KEY (NomeDepartamento)
);

-- Create table Biblioteca
CREATE TABLE Biblioteca (
  geom ast_polygon
);

-- Create the spatial index on geom column of Biblioteca
CREATE INDEX SIDX_Biblioteca
  ON Biblioteca
  USING GIST (geom);

-- Create table FCUL
CREATE TABLE FCUL (
);

-- Create table ServicoPontos
CREATE TABLE ServicoPontos (
  geom ast_point
);

-- Create the spatial index on geom column of ServicoPontos
CREATE INDEX SIDX_ServicoPontos
  ON ServicoPontos
  USING GIST (geom);

-- Create table EspacoVerde
CREATE TABLE EspacoVerde (
  IDSpaces INTEGER,
  Tipo TEXT,
  geom ast_polygon,
  CONSTRAINT pk_EspacoVerde PRIMARY KEY (IDSpaces)
);

-- Create the spatial index on geom column of EspacoVerde
CREATE INDEX SIDX_EspacoVerde
  ON EspacoVerde
  USING GIST (geom);

-- Create table Laboratorio
CREATE TABLE Laboratorio (
  geom ast_polygon
);

-- Create the spatial index on geom column of Laboratorio
CREATE INDEX SIDX_Laboratorio
  ON Laboratorio
  USING GIST (geom);

-- Create table Via
CREATE TABLE Via (
  geom ast_polygon
);

-- Create the spatial index on geom column of Via
CREATE INDEX SIDX_Via
  ON Via
  USING GIST (geom);

-- Create table Estrada
CREATE TABLE Estrada (
  Designacao TEXT,
  geom ast_polygon
);

-- Create the spatial index on geom column of Estrada
CREATE INDEX SIDX_Estrada
  ON Estrada
  USING GIST (geom);

-- Add new column (foreign key) on table Estrada due generalization-Via
ALTER TABLE Estrada

-- Add foreign key constraint on table Estrada due generalization-Via
ALTER TABLE Estrada ADD
  CONSTRAINT fk_Estrada_ref_Via
  FOREIGN KEY ()
  REFERENCES Via();

-- Create table Gabinete
CREATE TABLE Gabinete (
  Sala_NumeroSala TEXT,
  Sala_NomeEdificio TEXT,
  Sala_Capacidade INTEGER,
  geom ast_polygon,
  CONSTRAINT pk_Gabinete PRIMARY KEY (Sala_NumeroSala)
);

-- Create the spatial index on geom column of Gabinete
CREATE INDEX SIDX_Gabinete
  ON Gabinete
  USING GIST (geom);

-- Create table ServicoPoligonos
CREATE TABLE ServicoPoligonos (
  Servicos_IDServico INTEGER,
  Servicos_Tipo VARCHAR(50),
  geom ast_polygon,
  CONSTRAINT pk_ServicoPoligonos PRIMARY KEY (Servicos_IDServico)
);

-- Create the spatial index on geom column of ServicoPoligonos
CREATE INDEX SIDX_ServicoPoligonos
  ON ServicoPoligonos
  USING GIST (geom);

-- Add new column (foreign key) on table Edificio due conventional-aggregation-FCUL-Edificio
ALTER TABLE Edificio

-- Add foreign key constraint on table Edificio due conventional-aggregation-FCUL-Edificio
ALTER TABLE Edificio ADD
  CONSTRAINT fk_Edificio_ref_FCUL
  FOREIGN KEY ()
  REFERENCES FCUL();

-- Add new column (foreign key) on table Via due conventional-aggregation-FCUL-Via
ALTER TABLE Via

-- Add foreign key constraint on table Via due conventional-aggregation-FCUL-Via
ALTER TABLE Via ADD
  CONSTRAINT fk_Via_ref_FCUL
  FOREIGN KEY ()
  REFERENCES FCUL();

-- Add new column (foreign key) on table Aluno due conventional-relationship-Departamento--Aluno
ALTER TABLE Aluno
  ADD COLUMN Departamento_NomeDepartamento TEXT;

-- Add foreign key constraint on table Aluno due conventional-relationship-Departamento--Aluno
ALTER TABLE Aluno ADD
  CONSTRAINT fk_Aluno_ref_Departamento
  FOREIGN KEY (Departamento_NomeDepartamento)
  REFERENCES Departamento(NomeDepartamento);

-- Add new column (foreign key) on table EspacoVerde due conventional-aggregation-FCUL-EspacoVerde
ALTER TABLE EspacoVerde

-- Add foreign key constraint on table EspacoVerde due conventional-aggregation-FCUL-EspacoVerde
ALTER TABLE EspacoVerde ADD
  CONSTRAINT fk_EspacoVerde_ref_FCUL
  FOREIGN KEY ()
  REFERENCES FCUL();

-- Add new column (foreign key) on table CaminhoPedonal due conventional-aggregation-FCUL-CaminhoPedonal
ALTER TABLE CaminhoPedonal

-- Add foreign key constraint on table CaminhoPedonal due conventional-aggregation-FCUL-CaminhoPedonal
ALTER TABLE CaminhoPedonal ADD
  CONSTRAINT fk_CaminhoPedonal_ref_FCUL
  FOREIGN KEY ()
  REFERENCES FCUL();

-- Add new column (foreign key) on table Curso_UC due conventional-relationship-UnidadeCurricular--Curso_UC
ALTER TABLE Curso_UC
  ADD COLUMN UnidadeCurricular_CodigoUC TEXT;

-- Add foreign key constraint on table Curso_UC due conventional-relationship-UnidadeCurricular--Curso_UC
ALTER TABLE Curso_UC ADD
  CONSTRAINT fk_Curso_UC_ref_UnidadeCurricular
  FOREIGN KEY (UnidadeCurricular_CodigoUC)
  REFERENCES UnidadeCurricular(CodigoUC);

-- Add new column (foreign key) on table Curso_UC due conventional-relationship-Curso_UC--Curso
ALTER TABLE Curso_UC
  ADD COLUMN Curso_NomeCurso TEXT;

-- Add foreign key constraint on table Curso_UC due conventional-relationship-Curso_UC--Curso
ALTER TABLE Curso_UC ADD
  CONSTRAINT fk_Curso_UC_ref_Curso
  FOREIGN KEY (Curso_NomeCurso)
  REFERENCES Curso(NomeCurso);

-- Add new column (foreign key) on table Sala_UC due conventional-relationship-SalaAula--Sala_UC
ALTER TABLE Sala_UC

-- Add foreign key constraint on table Sala_UC due conventional-relationship-SalaAula--Sala_UC
ALTER TABLE Sala_UC ADD
  CONSTRAINT fk_Sala_UC_ref_SalaAula
  FOREIGN KEY ()
  REFERENCES SalaAula();

-- Add new column (foreign key) on table Curso due conventional-relationship-Departamento--Curso
ALTER TABLE Curso
  ADD COLUMN Departamento_NomeDepartamento TEXT;

-- Add foreign key constraint on table Curso due conventional-relationship-Departamento--Curso
ALTER TABLE Curso ADD
  CONSTRAINT fk_Curso_ref_Departamento
  FOREIGN KEY (Departamento_NomeDepartamento)
  REFERENCES Departamento(NomeDepartamento);

-- Add new column (foreign key) on table Docente_UC due conventional-relationship-UnidadeCurricular--Docente_UC
ALTER TABLE Docente_UC
  ADD COLUMN UnidadeCurricular_CodigoUC TEXT;

-- Add foreign key constraint on table Docente_UC due conventional-relationship-UnidadeCurricular--Docente_UC
ALTER TABLE Docente_UC ADD
  CONSTRAINT fk_Docente_UC_ref_UnidadeCurricular
  FOREIGN KEY (UnidadeCurricular_CodigoUC)
  REFERENCES UnidadeCurricular(CodigoUC);

-- Add new column (foreign key) on table Departamento due conventional-aggregation-FCUL-Departamento
ALTER TABLE Departamento

-- Add foreign key constraint on table Departamento due conventional-aggregation-FCUL-Departamento
ALTER TABLE Departamento ADD
  CONSTRAINT fk_Departamento_ref_FCUL
  FOREIGN KEY ()
  REFERENCES FCUL();

-- Add new column (foreign key) on table Docente due conventional-relationship-Gabinete--Docente
ALTER TABLE Docente
  ADD COLUMN Gabinete_Sala_NumeroSala TEXT;

-- Add foreign key constraint on table Docente due conventional-relationship-Gabinete--Docente
ALTER TABLE Docente ADD
  CONSTRAINT fk_Docente_ref_Gabinete
  FOREIGN KEY (Gabinete_Sala_NumeroSala)
  REFERENCES Gabinete(Sala_NumeroSala);

-- Add new column (foreign key) on table Sala_UC due conventional-relationship-SalaComputadores--Sala_UC
ALTER TABLE Sala_UC

-- Add foreign key constraint on table Sala_UC due conventional-relationship-SalaComputadores--Sala_UC
ALTER TABLE Sala_UC ADD
  CONSTRAINT fk_Sala_UC_ref_SalaComputadores
  FOREIGN KEY ()
  REFERENCES SalaComputadores();

-- Add new column (foreign key) on table Sala_UC due conventional-relationship-UnidadeCurricular--Sala_UC
ALTER TABLE Sala_UC
  ADD COLUMN UnidadeCurricular_CodigoUC TEXT;

-- Add foreign key constraint on table Sala_UC due conventional-relationship-UnidadeCurricular--Sala_UC
ALTER TABLE Sala_UC ADD
  CONSTRAINT fk_Sala_UC_ref_UnidadeCurricular
  FOREIGN KEY (UnidadeCurricular_CodigoUC)
  REFERENCES UnidadeCurricular(CodigoUC);

-- Add new column (foreign key) on table Aluno due conventional-relationship-Aluno--Curso
ALTER TABLE Aluno
  ADD COLUMN Curso_NomeCurso TEXT;

-- Add foreign key constraint on table Aluno due conventional-relationship-Aluno--Curso
ALTER TABLE Aluno ADD
  CONSTRAINT fk_Aluno_ref_Curso
  FOREIGN KEY (Curso_NomeCurso)
  REFERENCES Curso(NomeCurso);

-- Add new column (foreign key) on table Docente due conventional-relationship-Departamento--Docente
ALTER TABLE Docente
  ADD COLUMN Departamento_NomeDepartamento TEXT;

-- Add foreign key constraint on table Docente due conventional-relationship-Departamento--Docente
ALTER TABLE Docente ADD
  CONSTRAINT fk_Docente_ref_Departamento
  FOREIGN KEY (Departamento_NomeDepartamento)
  REFERENCES Departamento(NomeDepartamento);

-- Add new column (foreign key) on table Docente_UC due conventional-relationship-Docente_UC--Docente
ALTER TABLE Docente_UC
  ADD COLUMN Docente_NumeroFuncionario INTEGER;

-- Add foreign key constraint on table Docente_UC due conventional-relationship-Docente_UC--Docente
ALTER TABLE Docente_UC ADD
  CONSTRAINT fk_Docente_UC_ref_Docente
  FOREIGN KEY (Docente_NumeroFuncionario)
  REFERENCES Docente(NumeroFuncionario);

-- Add new column (foreign key) on table Servicos due conventional-aggregation-Edificio-Servicos
ALTER TABLE Servicos
  ADD COLUMN Edificio_NomeEdificio TEXT;

-- Add foreign key constraint on table Servicos due conventional-aggregation-Edificio-Servicos
ALTER TABLE Servicos ADD
  CONSTRAINT fk_Servicos_ref_Edificio
  FOREIGN KEY (Edificio_NomeEdificio)
  REFERENCES Edificio(NomeEdificio);

-- Add new column (foreign key) on table Gabinete due conventional-relationship-Departamento--Gabinete
ALTER TABLE Gabinete
  ADD COLUMN Departamento_NomeDepartamento TEXT;

-- Add foreign key constraint on table Gabinete due conventional-relationship-Departamento--Gabinete
ALTER TABLE Gabinete ADD
  CONSTRAINT fk_Gabinete_ref_Departamento
  FOREIGN KEY (Departamento_NomeDepartamento)
  REFERENCES Departamento(NomeDepartamento);

-- Add new column (foreign key) on table Sala_UC due conventional-relationship-Laboratorio--Sala_UC
ALTER TABLE Sala_UC

-- Add foreign key constraint on table Sala_UC due conventional-relationship-Laboratorio--Sala_UC
ALTER TABLE Sala_UC ADD
  CONSTRAINT fk_Sala_UC_ref_Laboratorio
  FOREIGN KEY ()
  REFERENCES Laboratorio();

