-- Validate the network between the CaminhoPedonal and Cruzamento
CREATE TRIGGER caminhopedonal_cruzamento_arc_trigger
  AFTER INSERT OR UPDATE ON caminhopedonal
  FOR EACH STATEMENT
  EXECUTE PROCEDURE ast_arcnodenetwork('caminhopedonal', 'geom', 'cruzamento', 'geom');
  
  
-- Validate the spatial aggregation between the whole Edificio and the part Gabinete
CREATE TRIGGER val_spa_agr_Edificio_Gabinete
AFTER INSERT OR UPDATE OR DELETE ON Gabinete
   FOR EACH STATEMENT
   EXECUTE PROCEDURE ast_aggregation('Gabinete', 'geom', 'Edificio', 'geom');

   
