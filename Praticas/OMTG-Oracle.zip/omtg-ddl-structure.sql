-- Create table Docente
CREATE TABLE Docente (
  NumeroFuncionario INTEGER,
  Gabinete VARCHAR2(300),
  NomeDepartamento VARCHAR2(300),
  Nome VARCHAR2(300),
  Telefone INTEGER,
  Email VARCHAR2(300),
  CONSTRAINT pk_Docente PRIMARY KEY (NumeroFuncionario)
);
/
-- Create table Edificio
CREATE TABLE Edificio (
  NomeEdificio VARCHAR2(300),
  Descricao VARCHAR2(300),
  geom MDSYS.SDO_GEOMETRY,
  CONSTRAINT pk_Edificio PRIMARY KEY (NomeEdificio)
);
/
-- Insert the geom column of Edificio into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Edificio', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Edificio
CREATE INDEX SIDX_Edificio ON Edificio(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table Curso_UC
CREATE TABLE Curso_UC (
  NomeCurso VARCHAR2(300),
  CodigoUC INTEGER,
  CONSTRAINT pk_Curso_UC PRIMARY KEY (NomeCurso,CodigoUC)
);
/
-- Create table Cruzamento
CREATE TABLE Cruzamento (
  geom MDSYS.SDO_GEOMETRY
);
/
-- Insert the geom column of Cruzamento into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Cruzamento', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Cruzamento
CREATE INDEX SIDX_Cruzamento ON Cruzamento(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POINT');
/
-- Create table Aluno
CREATE TABLE Aluno (
  NumeroAluno INTEGER,
  Nome VARCHAR2(300),
  Telefone INTEGER,
  Email VARCHAR2(300),
  Morada VARCHAR2(300),
  NomeCurso VARCHAR2(300),
  CONSTRAINT pk_Aluno PRIMARY KEY (NumeroAluno)
);
/
-- Create table SalaAula
CREATE TABLE SalaAula (
  geom MDSYS.SDO_GEOMETRY
);
/
-- Insert the geom column of SalaAula into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('SalaAula', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of SalaAula
CREATE INDEX SIDX_SalaAula ON SalaAula(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table Estacionamento
CREATE TABLE Estacionamento (
  Designacao VARCHAR2(300),
  Espacos INTEGER,
  geom MDSYS.SDO_GEOMETRY
);
/
-- Insert the geom column of Estacionamento into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Estacionamento', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Estacionamento
CREATE INDEX SIDX_Estacionamento ON Estacionamento(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table Curso
CREATE TABLE Curso (
  NomeCurso VARCHAR2(300),
  Ciclo INTEGER,
  Descricao VARCHAR2(300),
  CONSTRAINT pk_Curso PRIMARY KEY (NomeCurso)
);
/
-- Create table UnidadeCurricular
CREATE TABLE UnidadeCurricular (
  NomeUC VARCHAR2(300),
  CodigoUC VARCHAR2(300),
  Ciclo INTEGER,
  Descricao VARCHAR2(300),
  ECTS INTEGER,
  CONSTRAINT pk_UnidadeCurricular PRIMARY KEY (CodigoUC)
);
/
-- Create table CaminhoPedonal
CREATE TABLE CaminhoPedonal (
  Nome VARCHAR2(300),
  geom MDSYS.SDO_GEOMETRY
);
/
-- Insert the geom column of CaminhoPedonal into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('CaminhoPedonal', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of CaminhoPedonal
CREATE INDEX SIDX_CaminhoPedonal ON CaminhoPedonal(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=LINESTRING');
/
-- Create table SalaComputadores
CREATE TABLE SalaComputadores (
  NrPcs INTEGER,
  geom MDSYS.SDO_GEOMETRY
);
/
-- Insert the geom column of SalaComputadores into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('SalaComputadores', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of SalaComputadores
CREATE INDEX SIDX_SalaComputadores ON SalaComputadores(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table Sala_UC
CREATE TABLE Sala_UC (
  NumeroSala VARCHAR2(300),
  CodigoUC VARCHAR2(300),
  CONSTRAINT pk_Sala_UC PRIMARY KEY (NumeroSala,CodigoUC)
);
/
-- Create table Docente_UC
CREATE TABLE Docente_UC (
  NumeroFuncionario INTEGER,
  CodigoUC INTEGER,
  CONSTRAINT pk_Docente_UC PRIMARY KEY (NumeroFuncionario,CodigoUC)
);
/
-- Create table Departamento
CREATE TABLE Departamento (
  NomeDepartamento VARCHAR2(300),
  CONSTRAINT pk_Departamento PRIMARY KEY (NomeDepartamento)
);
/
-- Create table Biblioteca
CREATE TABLE Biblioteca (
  geom MDSYS.SDO_GEOMETRY
);
/
-- Insert the geom column of Biblioteca into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Biblioteca', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Biblioteca
CREATE INDEX SIDX_Biblioteca ON Biblioteca(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table FCUL
CREATE TABLE FCUL (
);
/
-- Create table ServicoPontos
CREATE TABLE ServicoPontos (
  geom MDSYS.SDO_GEOMETRY
);
/
-- Insert the geom column of ServicoPontos into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('ServicoPontos', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of ServicoPontos
CREATE INDEX SIDX_ServicoPontos ON ServicoPontos(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POINT');
/
-- Create table EspacoVerde
CREATE TABLE EspacoVerde (
  IDSpaces INTEGER,
  Tipo VARCHAR2(300),
  geom MDSYS.SDO_GEOMETRY,
  CONSTRAINT pk_EspacoVerde PRIMARY KEY (IDSpaces)
);
/
-- Insert the geom column of EspacoVerde into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('EspacoVerde', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of EspacoVerde
CREATE INDEX SIDX_EspacoVerde ON EspacoVerde(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table Laboratorio
CREATE TABLE Laboratorio (
  geom MDSYS.SDO_GEOMETRY
);
/
-- Insert the geom column of Laboratorio into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Laboratorio', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Laboratorio
CREATE INDEX SIDX_Laboratorio ON Laboratorio(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table Via
CREATE TABLE Via (
  geom MDSYS.SDO_GEOMETRY
);
/
-- Insert the geom column of Via into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Via', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Via
CREATE INDEX SIDX_Via ON Via(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table Estrada
CREATE TABLE Estrada (
  Designacao VARCHAR2(300),
  geom MDSYS.SDO_GEOMETRY
);
/
-- Insert the geom column of Estrada into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Estrada', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Estrada
CREATE INDEX SIDX_Estrada ON Estrada(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Add new column (foreign key) on table Estrada due generalization-Via
ALTER TABLE Estrada ADD (
);
/
-- Add foreign key constraint on table Estrada due generalization-Via
ALTER TABLE Estrada ADD
  CONSTRAINT fk_Estrada_ref_Via
  FOREIGN KEY ()
  REFERENCES Via();
/
-- Create table Gabinete
CREATE TABLE Gabinete (
  Sala_NumeroSala VARCHAR2(300),
  Sala_NomeEdificio VARCHAR2(300),
  Sala_Capacidade INTEGER,
  geom MDSYS.SDO_GEOMETRY,
  CONSTRAINT pk_Gabinete PRIMARY KEY (Sala_NumeroSala)
);
/
-- Insert the geom column of Gabinete into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Gabinete', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Gabinete
CREATE INDEX SIDX_Gabinete ON Gabinete(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table ServicoPoligonos
CREATE TABLE ServicoPoligonos (
  Servicos_IDServico INTEGER,
  Servicos_Tipo VARCHAR2(50),
  geom MDSYS.SDO_GEOMETRY,
  CONSTRAINT pk_ServicoPoligonos PRIMARY KEY (Servicos_IDServico)
);
/
-- Insert the geom column of ServicoPoligonos into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('ServicoPoligonos', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of ServicoPoligonos
CREATE INDEX SIDX_ServicoPoligonos ON ServicoPoligonos(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Add new column (foreign key) on table Edificio due conventional-aggregation-FCUL-Edificio
ALTER TABLE Edificio ADD (
);
/
-- Add foreign key constraint on table Edificio due conventional-aggregation-FCUL-Edificio
ALTER TABLE Edificio ADD
  CONSTRAINT fk_Edificio_ref_FCUL
  FOREIGN KEY ()
  REFERENCES FCUL();
/
-- Add new column (foreign key) on table Via due conventional-aggregation-FCUL-Via
ALTER TABLE Via ADD (
);
/
-- Add foreign key constraint on table Via due conventional-aggregation-FCUL-Via
ALTER TABLE Via ADD
  CONSTRAINT fk_Via_ref_FCUL
  FOREIGN KEY ()
  REFERENCES FCUL();
/
-- Add new column (foreign key) on table Aluno due conventional-relationship-Departamento--Aluno
ALTER TABLE Aluno ADD (
  Departamento_NomeDepartamento VARCHAR2(300)
);
/
-- Add foreign key constraint on table Aluno due conventional-relationship-Departamento--Aluno
ALTER TABLE Aluno ADD
  CONSTRAINT fk_Aluno_ref_Departamento
  FOREIGN KEY (Departamento_NomeDepartamento)
  REFERENCES Departamento(NomeDepartamento);
/
-- Add new column (foreign key) on table EspacoVerde due conventional-aggregation-FCUL-EspacoVerde
ALTER TABLE EspacoVerde ADD (
);
/
-- Add foreign key constraint on table EspacoVerde due conventional-aggregation-FCUL-EspacoVerde
ALTER TABLE EspacoVerde ADD
  CONSTRAINT fk_EspacoVerde_ref_FCUL
  FOREIGN KEY ()
  REFERENCES FCUL();
/
-- Add new column (foreign key) on table CaminhoPedonal due conventional-aggregation-FCUL-CaminhoPedonal
ALTER TABLE CaminhoPedonal ADD (
);
/
-- Add foreign key constraint on table CaminhoPedonal due conventional-aggregation-FCUL-CaminhoPedonal
ALTER TABLE CaminhoPedonal ADD
  CONSTRAINT fk_CaminhoPedonal_ref_FCUL
  FOREIGN KEY ()
  REFERENCES FCUL();
/
-- Add new column (foreign key) on table Curso_UC due conventional-relationship-UnidadeCurricular--Curso_UC
ALTER TABLE Curso_UC ADD (
  UnidadeCurricular_CodigoUC VARCHAR2(300)
);
/
-- Add foreign key constraint on table Curso_UC due conventional-relationship-UnidadeCurricular--Curso_UC
ALTER TABLE Curso_UC ADD
  CONSTRAINT fk_Curso_UC_ref_UnidadeCurricular
  FOREIGN KEY (UnidadeCurricular_CodigoUC)
  REFERENCES UnidadeCurricular(CodigoUC);
/
-- Add new column (foreign key) on table Curso_UC due conventional-relationship-Curso_UC--Curso
ALTER TABLE Curso_UC ADD (
  Curso_NomeCurso VARCHAR2(300)
);
/
-- Add foreign key constraint on table Curso_UC due conventional-relationship-Curso_UC--Curso
ALTER TABLE Curso_UC ADD
  CONSTRAINT fk_Curso_UC_ref_Curso
  FOREIGN KEY (Curso_NomeCurso)
  REFERENCES Curso(NomeCurso);
/
-- Add new column (foreign key) on table Sala_UC due conventional-relationship-SalaAula--Sala_UC
ALTER TABLE Sala_UC ADD (
);
/
-- Add foreign key constraint on table Sala_UC due conventional-relationship-SalaAula--Sala_UC
ALTER TABLE Sala_UC ADD
  CONSTRAINT fk_Sala_UC_ref_SalaAula
  FOREIGN KEY ()
  REFERENCES SalaAula();
/
-- Add new column (foreign key) on table Curso due conventional-relationship-Departamento--Curso
ALTER TABLE Curso ADD (
  Departamento_NomeDepartamento VARCHAR2(300)
);
/
-- Add foreign key constraint on table Curso due conventional-relationship-Departamento--Curso
ALTER TABLE Curso ADD
  CONSTRAINT fk_Curso_ref_Departamento
  FOREIGN KEY (Departamento_NomeDepartamento)
  REFERENCES Departamento(NomeDepartamento);
/
-- Add new column (foreign key) on table Docente_UC due conventional-relationship-UnidadeCurricular--Docente_UC
ALTER TABLE Docente_UC ADD (
  UnidadeCurricular_CodigoUC VARCHAR2(300)
);
/
-- Add foreign key constraint on table Docente_UC due conventional-relationship-UnidadeCurricular--Docente_UC
ALTER TABLE Docente_UC ADD
  CONSTRAINT fk_Docente_UC_ref_UnidadeCurricular
  FOREIGN KEY (UnidadeCurricular_CodigoUC)
  REFERENCES UnidadeCurricular(CodigoUC);
/
-- Add new column (foreign key) on table Departamento due conventional-aggregation-FCUL-Departamento
ALTER TABLE Departamento ADD (
);
/
-- Add foreign key constraint on table Departamento due conventional-aggregation-FCUL-Departamento
ALTER TABLE Departamento ADD
  CONSTRAINT fk_Departamento_ref_FCUL
  FOREIGN KEY ()
  REFERENCES FCUL();
/
-- Add new column (foreign key) on table Docente due conventional-relationship-Gabinete--Docente
ALTER TABLE Docente ADD (
  Gabinete_Sala_NumeroSala VARCHAR2(300)
);
/
-- Add foreign key constraint on table Docente due conventional-relationship-Gabinete--Docente
ALTER TABLE Docente ADD
  CONSTRAINT fk_Docente_ref_Gabinete
  FOREIGN KEY (Gabinete_Sala_NumeroSala)
  REFERENCES Gabinete(Sala_NumeroSala);
/
-- Create the Spatial_error table to contains spatial integrity constraint error messages
CREATE TABLE Spatial_error (
  type VARCHAR2(100),
  error VARCHAR2(500)
);
/
-- Add new column (foreign key) on table Sala_UC due conventional-relationship-SalaComputadores--Sala_UC
ALTER TABLE Sala_UC ADD (
);
/
-- Add foreign key constraint on table Sala_UC due conventional-relationship-SalaComputadores--Sala_UC
ALTER TABLE Sala_UC ADD
  CONSTRAINT fk_Sala_UC_ref_SalaComputadores
  FOREIGN KEY ()
  REFERENCES SalaComputadores();
/
-- Add new column (foreign key) on table Sala_UC due conventional-relationship-UnidadeCurricular--Sala_UC
ALTER TABLE Sala_UC ADD (
  UnidadeCurricular_CodigoUC VARCHAR2(300)
);
/
-- Add foreign key constraint on table Sala_UC due conventional-relationship-UnidadeCurricular--Sala_UC
ALTER TABLE Sala_UC ADD
  CONSTRAINT fk_Sala_UC_ref_UnidadeCurricular
  FOREIGN KEY (UnidadeCurricular_CodigoUC)
  REFERENCES UnidadeCurricular(CodigoUC);
/
-- Add new column (foreign key) on table Aluno due conventional-relationship-Aluno--Curso
ALTER TABLE Aluno ADD (
  Curso_NomeCurso VARCHAR2(300)
);
/
-- Add foreign key constraint on table Aluno due conventional-relationship-Aluno--Curso
ALTER TABLE Aluno ADD
  CONSTRAINT fk_Aluno_ref_Curso
  FOREIGN KEY (Curso_NomeCurso)
  REFERENCES Curso(NomeCurso);
/
-- Add new column (foreign key) on table Docente due conventional-relationship-Departamento--Docente
ALTER TABLE Docente ADD (
  Departamento_NomeDepartamento VARCHAR2(300)
);
/
-- Add foreign key constraint on table Docente due conventional-relationship-Departamento--Docente
ALTER TABLE Docente ADD
  CONSTRAINT fk_Docente_ref_Departamento
  FOREIGN KEY (Departamento_NomeDepartamento)
  REFERENCES Departamento(NomeDepartamento);
/
-- Add new column (foreign key) on table Docente_UC due conventional-relationship-Docente_UC--Docente
ALTER TABLE Docente_UC ADD (
  Docente_NumeroFuncionario INTEGER
);
/
-- Add foreign key constraint on table Docente_UC due conventional-relationship-Docente_UC--Docente
ALTER TABLE Docente_UC ADD
  CONSTRAINT fk_Docente_UC_ref_Docente
  FOREIGN KEY (Docente_NumeroFuncionario)
  REFERENCES Docente(NumeroFuncionario);
/
-- Add new column (foreign key) on table Servicos due conventional-aggregation-Edificio-Servicos
ALTER TABLE Servicos ADD (
  Edificio_NomeEdificio VARCHAR2(300)
);
/
-- Add foreign key constraint on table Servicos due conventional-aggregation-Edificio-Servicos
ALTER TABLE Servicos ADD
  CONSTRAINT fk_Servicos_ref_Edificio
  FOREIGN KEY (Edificio_NomeEdificio)
  REFERENCES Edificio(NomeEdificio);
/
-- Add new column (foreign key) on table Gabinete due conventional-relationship-Departamento--Gabinete
ALTER TABLE Gabinete ADD (
  Departamento_NomeDepartamento VARCHAR2(300)
);
/
-- Add foreign key constraint on table Gabinete due conventional-relationship-Departamento--Gabinete
ALTER TABLE Gabinete ADD
  CONSTRAINT fk_Gabinete_ref_Departamento
  FOREIGN KEY (Departamento_NomeDepartamento)
  REFERENCES Departamento(NomeDepartamento);
/
-- Create the Sa_aux table to support spatial aggregation constraint
CREATE TABLE Sa_aux (
  w_rowid ROWID,
  p_rowid ROWID,
  p_geom MDSYS.SDO_GEOMETRY
);
/
-- Insert the geom column of Sa_aux into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Sa_aux', 'p_geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Sa_aux
CREATE INDEX SIDX_Sa_aux ON Sa_aux(p_geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Add new column (foreign key) on table Sala_UC due conventional-relationship-Laboratorio--Sala_UC
ALTER TABLE Sala_UC ADD (
);
/
-- Add foreign key constraint on table Sala_UC due conventional-relationship-Laboratorio--Sala_UC
ALTER TABLE Sala_UC ADD
  CONSTRAINT fk_Sala_UC_ref_Laboratorio
  FOREIGN KEY ()
  REFERENCES Laboratorio();
/
