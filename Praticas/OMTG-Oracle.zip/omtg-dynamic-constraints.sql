-- Validate the disjoint constraint on subclass Estrada
CREATE OR REPLACE TRIGGER val_disjoint_gen_Estrada
   BEFORE INSERT OR UPDATE ON Estrada
   REFERENCING NEW AS NEW OLD AS OLD
   FOR EACH ROW
DECLARE
   n NUMBER;
BEGIN


END;
/
